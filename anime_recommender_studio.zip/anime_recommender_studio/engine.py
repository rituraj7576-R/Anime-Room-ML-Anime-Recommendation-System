
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Sequence

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"

MOOD_RULES = {
    "Dark": {
        "genres": {"Psychological", "Thriller", "Mystery", "Horror", "Drama"},
        "tags": {"dark", "intense", "mind_game"},
        "description": "High-stakes, serious atmosphere, twisty tension, and less comfort-watch energy."
    },
    "Funny": {
        "genres": {"Comedy", "Slice of Life", "School"},
        "tags": {"funny", "comfort", "quirky"},
        "description": "Low mental load and easier fun. Good when you want something lighter."
    },
    "Emotional": {
        "genres": {"Drama", "Romance", "Slice of Life", "Fantasy"},
        "tags": {"emotional", "healing", "romantic"},
        "description": "Character-first stories with payoff, heart, and memorable emotional moments."
    },
    "Chill": {
        "genres": {"Slice of Life", "Fantasy", "Adventure"},
        "tags": {"chill", "healing", "comfort", "wonder"},
        "description": "Calmer pacing, softer vibes, and a better fit for relaxing."
    },
    "Mind Game": {
        "genres": {"Psychological", "Mystery", "Thriller", "Sci-Fi"},
        "tags": {"mind_game", "dark"},
        "description": "Strategy, theories, and endings that make you sit still for a minute."
    },
    "Intense": {
        "genres": {"Action", "Drama", "Fantasy", "Sci-Fi", "Adventure"},
        "tags": {"intense", "epic", "motivational"},
        "description": "Momentum-heavy, larger stakes, stronger payoff, and more adrenaline."
    },
}

RUNTIME_FILTERS = {
    "Very short (movie / 1-13 eps)": (1, 13),
    "Short (12-26 eps)": (12, 26),
    "Medium (20-50 eps)": (20, 50),
    "Anything": (1, 1000),
    "Long commitment (50+ eps)": (50, 1000),
}

QUIZ = [
    {"question": "What matters most first?", "choices": ["Plot twists", "Characters", "Feel-good vibe", "Action"]},
    {"question": "How heavy do you want it?", "choices": ["Very dark", "Balanced", "Light", "I want chaos"]},
    {"question": "Preferred pace?", "choices": ["Fast", "Medium", "Slow and rich", "Anything"]},
    {"question": "What ending style do you enjoy more?", "choices": ["Bittersweet", "Happy", "Unpredictable", "Doesn't matter"]},
]

MODE_CONFIG = {
    "Balanced": {"popularity": 0.10, "hidden_bonus": 0.06, "mainstream_bonus": 0.02},
    "Popular picks": {"popularity": 0.18, "hidden_bonus": -0.02, "mainstream_bonus": 0.08},
    "Hidden gems": {"popularity": -0.02, "hidden_bonus": 0.12, "mainstream_bonus": -0.03},
}


@dataclass
class AnimeRecommender:
    def __post_init__(self) -> None:
        self.anime = pd.read_csv(DATA / "anime.csv")
        self.ratings = pd.read_csv(DATA / "ratings.csv")
        self.titles = self.anime["name"].tolist()
        self.name_to_index = {name: i for i, name in enumerate(self.titles)}
        self.id_to_index = {aid: i for i, aid in enumerate(self.anime["anime_id"])}
        self.genres = sorted({g.strip() for g in self.anime["genre"].str.split(",").explode() if g.strip()})

        self.anime["popularity_label"] = self.anime["popularity_tier"].map({
            "mainstream": "popular",
            "balanced": "balanced",
            "hidden": "underrated",
        })
        self.anime["profile_text"] = (
            self.anime["genre"].fillna("") + " " +
            self.anime["synopsis"].fillna("") + " " +
            self.anime["studio"].fillna("") + " " +
            self.anime["mood_tags"].fillna("").str.replace(",", " ") + " " +
            self.anime["themes"].fillna("").str.replace(",", " ")
        )
        self._fit_models()

    def _fit_models(self) -> None:
        vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
        tfidf = vectorizer.fit_transform(self.anime["profile_text"])
        self.content_sim = cosine_similarity(tfidf)

        pivot = self.ratings.pivot_table(index="user_id", columns="anime_id", values="rating")
        corr = pivot.corr(method="pearson", min_periods=5).fillna(0.0)
        corr = corr.reindex(index=self.anime["anime_id"], columns=self.anime["anime_id"], fill_value=0.0)
        self.collab_sim = corr.to_numpy(dtype=float)

        self.rating_scaled = self._scale(self.anime["rating"].to_numpy(dtype=float))
        self.members_scaled = self._scale(np.log1p(self.anime["members"].to_numpy(dtype=float)))
        self.hidden_scaled = np.where(self.anime["popularity_tier"].eq("hidden"), 1.0,
                               np.where(self.anime["popularity_tier"].eq("balanced"), 0.45, 0.1))

    @staticmethod
    def _scale(values: np.ndarray) -> np.ndarray:
        lo, hi = values.min(), values.max()
        if hi == lo:
            return np.zeros_like(values, dtype=float)
        return (values - lo) / (hi - lo)

    def _indices(self, titles: Sequence[str]) -> list[int]:
        return [self.name_to_index[t] for t in titles if t in self.name_to_index]

    def _genre_overlap_score(self, liked_indices: list[int]) -> np.ndarray:
        liked_genres = set()
        for i in liked_indices:
            liked_genres.update(g.strip() for g in self.anime.iloc[i]["genre"].split(",") if g.strip())
        scores = []
        for text in self.anime["genre"]:
            current = {g.strip() for g in text.split(",") if g.strip()}
            denom = max(1, len(liked_genres | current))
            scores.append(len(liked_genres & current) / denom)
        return np.array(scores, dtype=float)

    def _mood_score(self, mood: str) -> np.ndarray:
        if mood == "Any":
            return np.full(len(self.anime), 0.45, dtype=float)
        rule = MOOD_RULES[mood]
        scores = []
        for _, row in self.anime.iterrows():
            row_genres = {g.strip() for g in row["genre"].split(",")}
            row_tags = {t.strip() for t in row["mood_tags"].split(",")}
            genre_hits = len(rule["genres"] & row_genres)
            tag_hits = len(rule["tags"] & row_tags)
            scores.append(min(1.0, genre_hits * 0.17 + tag_hits * 0.22))
        return np.array(scores, dtype=float)

    def _runtime_score(self, runtime: str) -> np.ndarray:
        lo, hi = RUNTIME_FILTERS[runtime]
        scores = []
        for ep, kind in zip(self.anime["episodes"], self.anime["type"]):
            if lo <= ep <= hi:
                scores.append(1.0)
            elif runtime == "Anything":
                scores.append(0.7)
            elif kind == "Movie" and lo <= 2:
                scores.append(0.9)
            else:
                gap = min(abs(ep - lo), abs(ep - hi))
                scores.append(max(0.0, 1 - gap / 40))
        return np.array(scores, dtype=float)

    def _novelty_score(self) -> np.ndarray:
        return np.clip((1 - self.members_scaled) * 0.7 + self.hidden_scaled * 0.3, 0, 1)

    def recommend(
        self,
        liked_titles: Sequence[str],
        mood: str = "Any",
        runtime: str = "Anything",
        mode: str = "Balanced",
        must_genre: str = "Any",
        top_n: int = 8,
        weights: dict[str, float] | None = None,
    ) -> list[dict]:
        liked_idx = self._indices(liked_titles)
        if not liked_idx:
            return []

        weights = weights or {"content": 0.32, "collab": 0.24, "fit": 0.16, "other": 0.28}
        content = self.content_sim[liked_idx].mean(axis=0)
        collab = self.collab_sim[liked_idx].mean(axis=0)
        collab = self._scale(collab)
        genre_overlap = self._genre_overlap_score(liked_idx)
        mood_fit = self._mood_score(mood)
        runtime_fit = self._runtime_score(runtime)
        quality = np.clip(self.rating_scaled * 0.78 + genre_overlap * 0.22, 0, 1)
        novelty = self._novelty_score()
        style = MODE_CONFIG[mode]

        score = (
            weights["content"] * content +
            weights["collab"] * collab +
            weights["fit"] * ((mood_fit * 0.55) + (runtime_fit * 0.45)) +
            weights["other"] * (quality * 0.54 + novelty * 0.24 + self.members_scaled * style["popularity"] + self.hidden_scaled * style["hidden_bonus"])
            + style["mainstream_bonus"] * np.where(self.anime["popularity_tier"].eq("mainstream"), 1.0, 0.0)
        )

        for i in liked_idx:
            score[i] = -1

        df = self.anime.copy()
        df["score"] = score
        if must_genre != "Any":
            df = df[df["genre"].str.contains(must_genre, case=False, na=False)]

        if runtime != "Anything":
            lo, hi = RUNTIME_FILTERS[runtime]
            df = df[(df["episodes"] >= lo) & (df["episodes"] <= hi)]

        if df.empty:
            return []

        ranked = df.sort_values("score", ascending=False).head(max(top_n * 3, top_n))
        reranked = self._diversity_rerank(ranked, top_n)
        return [self._row_to_card(row, liked_titles, mood, runtime, mode) for _, row in reranked.iterrows()]

    def _diversity_rerank(self, frame: pd.DataFrame, top_n: int) -> pd.DataFrame:
        chosen = []
        seen_genres: set[str] = set()
        pool = frame.copy()

        while len(chosen) < min(top_n, len(pool)):
            best_idx = None
            best_value = -999.0
            for idx, row in pool.iterrows():
                genres = {g.strip() for g in row["genre"].split(",") if g.strip()}
                diversity_bonus = 0.06 * len(genres - seen_genres)
                value = float(row["score"]) + diversity_bonus
                if value > best_value:
                    best_value = value
                    best_idx = idx
            if best_idx is None:
                break
            chosen.append(best_idx)
            seen_genres.update(g.strip() for g in pool.loc[best_idx, "genre"].split(",") if g.strip())
            pool = pool.drop(index=best_idx)

        return frame.loc[chosen]

    def _row_to_card(self, row: pd.Series, liked_titles: Sequence[str], mood: str, runtime: str, mode: str) -> dict:
        liked_rows = self.anime[self.anime["name"].isin(liked_titles)]
        liked_genres = set(liked_rows["genre"].str.split(",").explode().str.strip())
        current_genres = [g.strip() for g in row["genre"].split(",") if g.strip()]
        overlap = [g for g in current_genres if g in liked_genres]

        reasons = []
        if overlap:
            reasons.append(f"it matches your taste in {', '.join(overlap[:2])}")
        if row["studio"] in liked_rows["studio"].tolist():
            reasons.append("it comes from a studio already showing up in your picks")
        if mood != "Any":
            reasons.append(f"its mood leans {mood.lower()}")
        if runtime != "Anything" and row["episodes"] <= 26:
            reasons.append("it fits the time commitment you asked for")
        if mode == "Hidden gems" and row["popularity_tier"] == "hidden":
            reasons.append("this is the kind of lower-hype title this mode tries to surface")
        elif mode == "Popular picks" and row["popularity_tier"] == "mainstream":
            reasons.append("this is a safer crowd-pleaser")
        if not reasons:
            reasons.append("it landed in a strong middle ground across fit, quality, and novelty")

        return {
            "name": row["name"],
            "genre": row["genre"],
            "type": row["type"],
            "episodes": int(row["episodes"]),
            "rating": float(row["rating"]),
            "studio": row["studio"],
            "synopsis": row["synopsis"],
            "score": round(float(row["score"]), 2),
            "popularity_label": row["popularity_label"],
            "reason": "Recommended because " + ", ".join(reasons[:3]) + ".",
        }

    def profile_summary(self, liked_titles: Sequence[str]) -> dict:
        idx = self._indices(liked_titles)
        if not idx:
            return {"summary": "No titles selected yet.", "detail": "Choose some anime first.", "top_genre": "-"}
        genres = []
        tags = []
        for i in idx:
            genres.extend(g.strip() for g in self.anime.iloc[i]["genre"].split(",") if g.strip())
            tags.extend(t.strip() for t in self.anime.iloc[i]["mood_tags"].split(",") if t.strip())
        gcount = pd.Series(genres).value_counts()
        tcount = pd.Series(tags).value_counts()
        top_genres = gcount.head(3).index.tolist()
        top_tags = tcount.head(2).index.tolist()
        return {
            "summary": f"Your picks currently lean toward {', '.join(top_genres)}.",
            "detail": f"Detected vibe: {', '.join(top_tags).replace('_', ' ')}.",
            "top_genre": top_genres[0] if top_genres else "-"
        }

    def profile_radar(self, liked_titles: Sequence[str]) -> dict[str, list]:
        axes = ["Action", "Drama", "Fantasy", "Psychological", "Comedy", "Romance", "Slice of Life", "Mystery"]
        counts = dict.fromkeys(axes, 0)
        for title in liked_titles:
            if title not in self.name_to_index:
                continue
            row_genres = {g.strip() for g in self.anime.iloc[self.name_to_index[title]]["genre"].split(",")}
            for axis in axes:
                if axis in row_genres:
                    counts[axis] += 1
        max_count = max(counts.values()) if max(counts.values()) else 1
        return {"axis": axes, "score": [round(5 * counts[a] / max_count, 2) for a in axes]}

    def mood_pack(self, mood: str, runtime: str, mode: str, top_n: int = 6) -> list[dict]:
        seed_titles = (
            self.anime[self.anime["mood_tags"].str.contains("|".join(MOOD_RULES[mood]["tags"]), case=False, na=False)]["name"]
            .head(4)
            .tolist()
        )
        if not seed_titles:
            seed_titles = self.titles[:3]
        return self.recommend(seed_titles, mood=mood, runtime=runtime, mode=mode, top_n=top_n)

    def tonight_plan(self, mood: str, time_option: str, avoid_long: bool = True) -> dict[str, list[dict]]:
        if time_option == "Movie night":
            movie_pool = self.recommend(["Your Name", "A Silent Voice"], mood=mood, runtime="Very short (movie / 1-13 eps)", mode="Balanced", top_n=2)
            short_pool = self.recommend(["Barakamon", "Erased"], mood=mood, runtime="Short (12-26 eps)", mode="Balanced", top_n=2)
            return {"Movie pick": movie_pool[:1], "Short series pick": short_pool[:1]}
        if time_option == "Short series":
            picks = self.recommend(["Steins;Gate", "Horimiya"], mood=mood, runtime="Short (12-26 eps)", mode="Balanced", top_n=4)
            return {"Good short options": picks[:3]}
        picks = self.recommend(["Attack on Titan", "Fullmetal Alchemist: Brotherhood"], mood=mood, runtime="Medium (20-50 eps)" if avoid_long else "Anything", mode="Balanced", top_n=5)
        return {"Weekend binge options": picks[:4]}

    def compare(self, left: str, right: str) -> dict:
        l = self.anime.iloc[self.name_to_index[left]]
        r = self.anime.iloc[self.name_to_index[right]]
        l_genres = set(x.strip() for x in l["genre"].split(","))
        r_genres = set(x.strip() for x in r["genre"].split(","))
        shared = ", ".join(sorted(l_genres & r_genres)) or "very little direct genre overlap"
        difference = (
            f"{left} feels more {'plot-first' if 'Psychological' in l_genres or 'Mystery' in l_genres else 'emotion-first'}, "
            f"while {right} feels more {'plot-first' if 'Psychological' in r_genres or 'Mystery' in r_genres else 'emotion-first'}."
        )
        who_for = (
            f"Choose {left} if you want {', '.join(list(l_genres)[:2]).lower()} energy. "
            f"Choose {right} if you want {', '.join(list(r_genres)[:2]).lower()} energy."
        )
        table = pd.DataFrame({
            "Category": ["Rating", "Episodes", "Genres", "Studio", "Mood tags"],
            left: [l["rating"], l["episodes"], l["genre"], l["studio"], l["mood_tags"]],
            right: [r["rating"], r["episodes"], r["genre"], r["studio"], r["mood_tags"]],
        })
        return {"shared_vibe": shared, "difference": difference, "who_for": who_for, "table": table}

    def quiz_recommendation(self, answers: Sequence[str]) -> dict:
        if len(answers) < 4:
            return {"summary": "Answer all quiz questions first.", "note": "", "picks": []}
        mood = "Balanced"
        seeds = []

        if answers[0] == "Plot twists":
            mood = "Mind Game"
            seeds.extend(["Death Note", "Steins;Gate"])
        elif answers[0] == "Characters":
            mood = "Emotional"
            seeds.extend(["March Comes in Like a Lion", "Violet Evergarden"])
        elif answers[0] == "Feel-good vibe":
            mood = "Chill"
            seeds.extend(["Barakamon", "Natsume's Book of Friends"])
        else:
            mood = "Intense"
            seeds.extend(["Attack on Titan", "Vinland Saga"])

        if answers[1] == "Very dark":
            mood = "Dark"
        elif answers[1] == "Light":
            mood = "Funny"

        runtime = "Anything"
        if answers[2] == "Fast":
            runtime = "Short (12-26 eps)"
        elif answers[2] == "Slow and rich":
            runtime = "Medium (20-50 eps)"

        picks = self.recommend(seeds, mood=mood, runtime=runtime, mode="Balanced", top_n=5)
        return {
            "summary": f"Your quiz profile looks most like a {mood.lower()}-leaning watcher.",
            "note": "This quick quiz uses your answers as seed signals and then reranks by fit, diversity, and quality.",
            "picks": picks,
        }
