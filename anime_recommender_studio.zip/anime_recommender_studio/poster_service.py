from __future__ import annotations

import difflib
import json
from pathlib import Path
from urllib.parse import quote
from urllib.request import urlopen

BASE = Path(__file__).resolve().parent
CACHE_PATH = BASE / "data" / "poster_cache.json"


def _load_cache() -> dict:
    if CACHE_PATH.exists():
        try:
            return json.loads(CACHE_PATH.read_text())
        except Exception:
            return {}
    return {}


def _save_cache(cache: dict) -> None:
    try:
        CACHE_PATH.write_text(json.dumps(cache, indent=2))
    except Exception:
        pass


def get_poster_url(title: str) -> str | None:
    cache = _load_cache()
    if title in cache:
        return cache[title]

    try:
        url = f"https://api.jikan.moe/v4/anime?q={quote(title)}&limit=5"
        with urlopen(url, timeout=12) as response:
            payload = json.loads(response.read().decode("utf-8"))
        items = payload.get("data", [])
        if not items:
            cache[title] = None
            _save_cache(cache)
            return None

        best = None
        best_score = -1.0
        for item in items:
            names = [item.get("title") or "", item.get("title_english") or ""]
            for extra in item.get("titles", []) or []:
                names.append(extra.get("title", ""))
            score = max((difflib.SequenceMatcher(None, title.lower(), n.lower()).ratio() for n in names if n), default=0.0)
            if score > best_score:
                best_score = score
                best = item

        image_url = None
        if best:
            image_url = (
                best.get("images", {}).get("jpg", {}).get("large_image_url")
                or best.get("images", {}).get("jpg", {}).get("image_url")
            )
        cache[title] = image_url
        _save_cache(cache)
        return image_url
    except Exception:
        cache[title] = None
        _save_cache(cache)
        return None
