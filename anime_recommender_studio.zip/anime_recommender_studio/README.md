
# Anime Room

Anime Room is a more polished anime recommendation project built with Streamlit.

It is not just a "similar anime" demo. This version includes:
- hybrid scoring using content + community ratings
- mood-aware recommendations
- watch-length filters
- hidden gems / popular picks modes
- diversity reranking so results are less repetitive
- explainable recommendation cards
- taste radar chart
- compare-two-anime tool
- tonight planner
- quick taste quiz

## Project structure

```text
anime_recommender_studio/
├── app.py
├── engine.py
├── requirements.txt
├── README.md
├── assets/
└── data/
    ├── anime.csv
    └── ratings.csv
```

## Run locally

### 1) Install dependencies
```bash
py -m pip install -r requirements.txt
```

If `py` does not work:
```bash
python -m pip install -r requirements.txt
```

### 2) Start the app
```bash
py -m streamlit run app.py
```

or:
```bash
python -m streamlit run app.py
```

## Notes

- The dataset in `data/` is a curated demo dataset so the project runs immediately.
- You can replace `anime.csv` and `ratings.csv` later with a larger dataset.
- The recommendation logic is in `engine.py`.

## Tested

This package was smoke-tested for:
- CSV loading
- engine creation
- recommendation generation
- mood pack generation
- compare view generation
- quiz recommendation generation



## Posters

This version fetches poster images at runtime from the public Jikan anime API. If a poster is not available or the network fails, the UI falls back to a styled card so the app still works.
