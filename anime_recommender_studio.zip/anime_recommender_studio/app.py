from __future__ import annotations

import streamlit as st
import plotly.graph_objects as go

from engine import AnimeRecommender, MOOD_RULES, RUNTIME_FILTERS, QUIZ
from poster_service import get_poster_url

st.set_page_config(page_title="Anime Room", page_icon="🎴", layout="wide")

st.markdown("""
<style>
:root{
  --bg:#0f1220;
  --panel:#171b2d;
  --line:rgba(255,255,255,.09);
  --text:#f2f5ff;
  --muted:#b7c0df;
}
.stApp{
  background:
   radial-gradient(circle at 0% 0%, rgba(123,104,238,.22), transparent 24%),
   radial-gradient(circle at 100% 0%, rgba(61,217,197,.18), transparent 20%),
   linear-gradient(180deg,#0c1020 0%, #11162a 100%);
  color: var(--text);
}
.block-container{padding-top:1rem; padding-bottom:2rem; max-width:1220px;}
.hero,.panel,.mini,.card{border:1px solid var(--line); border-radius:22px; background:linear-gradient(180deg, rgba(255,255,255,.04), rgba(255,255,255,.02)); box-shadow:0 18px 40px rgba(0,0,0,.18);}
.hero{padding:1.3rem 1.35rem; margin-bottom:1rem;}
.hero h1{margin:.1rem 0 .35rem 0; font-size:2.2rem;}
.hero p{margin:0; color:var(--muted); line-height:1.65;}
.panel{padding:1rem; margin-bottom:1rem;}
.mini{padding:.9rem 1rem; text-align:center;}
.label{font-size:.78rem; color:var(--muted); text-transform:uppercase; letter-spacing:.08em;}
.big{font-size:1.4rem; font-weight:700;}
.card{overflow:hidden; margin-bottom:1rem;}
.poster-fallback{
  height: 300px; border-radius:18px;
  background:linear-gradient(135deg, rgba(123,104,238,.52), rgba(61,217,197,.35), rgba(255,122,162,.32));
  display:flex; align-items:flex-end; padding:1rem; font-weight:800; font-size:1.35rem;
}
.content{padding:1rem;}
.chip{display:inline-block; padding:.24rem .58rem; margin:0 .35rem .4rem 0; border-radius:999px; font-size:.76rem; border:1px solid rgba(255,255,255,.10); background:rgba(255,255,255,.05);}
.reason{color:#dce3ff; line-height:1.6;}
.small{color:var(--muted);}
.poster-tile{border:1px solid var(--line); border-radius:18px; overflow:hidden; background:rgba(255,255,255,.03); margin-bottom:.8rem;}
.poster-caption{padding:.6rem .75rem; font-size:.86rem; color:#eef2ff; min-height:48px;}
</style>
""", unsafe_allow_html=True)

@st.cache_resource
def load_engine() -> AnimeRecommender:
    return AnimeRecommender()

engine = load_engine()

if "likes" not in st.session_state:
    st.session_state.likes = ["Death Note", "Steins;Gate"]

st.markdown("""
<div class="hero">
  <h1>Anime Room</h1>
  <p>
    Now with poster images. The app still uses the same recommendation logic, but cards are now backed by anime poster art fetched at runtime.
    If an image is not found or the network is unavailable, the app falls back to a stylized local card so it still works.
  </p>
</div>
""", unsafe_allow_html=True)

with st.sidebar:
    st.header("Tune the recommendations")
    mood = st.selectbox("Mood", ["Any"] + list(MOOD_RULES.keys()))
    runtime = st.selectbox("Time commitment", list(RUNTIME_FILTERS.keys()), index=3)
    style = st.selectbox("Discovery mode", ["Balanced", "Popular picks", "Hidden gems"])
    must_genre = st.selectbox("Must include genre", ["Any"] + engine.genres)
    top_n = st.slider("How many recommendations?", 4, 12, 8)
    st.markdown("### Weight mix")
    w_content = st.slider("Content", 0.15, 0.60, 0.32, 0.01)
    w_collab = st.slider("Community", 0.10, 0.45, 0.24, 0.01)
    w_fit = st.slider("Mood + runtime fit", 0.05, 0.30, 0.16, 0.01)
    remaining = round(1 - (w_content + w_collab + w_fit), 2)
    st.caption(f"Remaining weight goes to quality + novelty + mode: {remaining}")


def recommendation_card(row: dict):
    chips = "".join([f"<span class='chip'>{x}</span>" for x in row["genre"].split(",")[:4]])
    chips += f"<span class='chip'>{row['type']}</span><span class='chip'>{row['popularity_label']}</span>"
    st.markdown("<div class='card'>", unsafe_allow_html=True)
    left, right = st.columns([1, 2.2])
    with left:
        poster_url = get_poster_url(row["name"])
        if poster_url:
            st.image(poster_url, use_container_width=True)
        else:
            st.markdown(f"<div class='poster-fallback'>{row['name']}</div>", unsafe_allow_html=True)
    with right:
        st.markdown(
            f"<div class='content'>{chips}<h3 style='margin-top:0'>{row['name']}</h3><p><span class='small'>{row['studio']} · ⭐ {row['rating']} · {row['episodes']} eps · match {row['score']:.2f}</span></p><p>{row['synopsis']}</p><p class='reason'><b>Why this was picked:</b> {row['reason']}</p></div>",
            unsafe_allow_html=True,
        )
    st.markdown("</div>", unsafe_allow_html=True)


def poster_gallery(rows: list[dict], title: str):
    st.markdown(f"### {title}")
    cols = st.columns(4)
    for i, row in enumerate(rows[:8]):
        with cols[i % 4]:
            poster_url = get_poster_url(row["name"])
            st.markdown("<div class='poster-tile'>", unsafe_allow_html=True)
            if poster_url:
                st.image(poster_url, use_container_width=True)
            else:
                st.markdown(f"<div class='poster-fallback' style='height:220px'>{row['name']}</div>", unsafe_allow_html=True)
            st.markdown(f"<div class='poster-caption'>{row['name']}</div>", unsafe_allow_html=True)
            st.markdown("</div>", unsafe_allow_html=True)


tab1, tab2, tab3, tab4, tab5 = st.tabs(["Main recommendations", "Mood mode", "Tonight planner", "Compare shows", "Taste quiz"])

with tab1:
    c1, c2 = st.columns([1.6, 1])
    with c1:
        likes = st.multiselect(
            "Choose 2 to 5 anime you already like",
            engine.titles,
            default=st.session_state.likes,
            max_selections=5,
        )
        st.session_state.likes = likes
    with c2:
        profile = engine.profile_summary(likes)
        st.markdown("<div class='panel'>", unsafe_allow_html=True)
        st.subheader("Your taste snapshot")
        st.write(profile["summary"])
        st.caption(profile["detail"])
        st.markdown("</div>", unsafe_allow_html=True)

    if likes:
        weights = {"content": w_content, "collab": w_collab, "fit": w_fit, "other": max(0.05, remaining)}
        recs = engine.recommend(likes, mood=mood, runtime=runtime, mode=style, must_genre=must_genre, top_n=top_n, weights=weights)

        m1, m2, m3, m4 = st.columns(4)
        m1.markdown(f"<div class='mini'><div class='label'>input shows</div><div class='big'>{len(likes)}</div></div>", unsafe_allow_html=True)
        m2.markdown(f"<div class='mini'><div class='label'>avg score</div><div class='big'>{round(sum(x['score'] for x in recs)/len(recs),2) if recs else 0}</div></div>", unsafe_allow_html=True)
        m3.markdown(f"<div class='mini'><div class='label'>top genre</div><div class='big'>{profile['top_genre']}</div></div>", unsafe_allow_html=True)
        m4.markdown(f"<div class='mini'><div class='label'>mode</div><div class='big'>{style}</div></div>", unsafe_allow_html=True)

        radar = engine.profile_radar(likes)
        fig = go.Figure()
        fig.add_trace(go.Scatterpolar(r=radar["score"], theta=radar["axis"], fill="toself", name="Taste"))
        fig.update_layout(height=360, margin=dict(l=10, r=10, t=10, b=10), showlegend=False)
        st.plotly_chart(fig, use_container_width=True)

        poster_gallery(recs, "Poster wall")
        for row in recs:
            recommendation_card(row)
    else:
        st.info("Pick a few titles to wake up the recommender.")

with tab2:
    mood_pick = st.selectbox("Pick a vibe", list(MOOD_RULES.keys()))
    st.caption(MOOD_RULES[mood_pick]["description"])
    pack = engine.mood_pack(mood_pick, runtime, style)
    poster_gallery(pack, f"{mood_pick} picks")
    for row in pack:
        recommendation_card(row)

with tab3:
    st.subheader("What should I watch tonight?")
    cc1, cc2, cc3 = st.columns(3)
    with cc1:
        tonight_mood = st.selectbox("Tonight's mood", ["Dark", "Funny", "Emotional", "Chill", "Mind Game", "Intense"], key="tm")
    with cc2:
        tonight_time = st.selectbox("How much time do you have?", ["Movie night", "Short series", "Weekend binge"], key="tt")
    with cc3:
        avoid_long = st.toggle("Avoid very long shows", value=True)

    plan = engine.tonight_plan(tonight_mood, tonight_time, avoid_long)
    for section, picks in plan.items():
        st.markdown(f"### {section}")
        for row in picks:
            recommendation_card(row)

with tab4:
    c1, c2 = st.columns(2)
    left = c1.selectbox("First anime", engine.titles, index=engine.titles.index("Death Note"))
    right = c2.selectbox("Second anime", engine.titles, index=engine.titles.index("Code Geass"))
    comparison = engine.compare(left, right)

    a, b, c = st.columns(3)
    a.markdown(f"<div class='panel'><b>Shared vibe</b><br><span class='small'>{comparison['shared_vibe']}</span></div>", unsafe_allow_html=True)
    b.markdown(f"<div class='panel'><b>Main difference</b><br><span class='small'>{comparison['difference']}</span></div>", unsafe_allow_html=True)
    c.markdown(f"<div class='panel'><b>Who should watch what?</b><br><span class='small'>{comparison['who_for']}</span></div>", unsafe_allow_html=True)
    st.dataframe(comparison["table"], use_container_width=True, hide_index=True)

with tab5:
    st.subheader("Quick taste quiz")
    answers = []
    for q in QUIZ:
        answers.append(st.radio(q["question"], q["choices"], horizontal=True, key=q["question"]))
    if st.button("Generate my anime vibe"):
        result = engine.quiz_recommendation(answers)
        st.success(result["summary"])
        st.caption(result["note"])
        poster_gallery(result["picks"], "Quiz picks")
        for row in result["picks"]:
            recommendation_card(row)
